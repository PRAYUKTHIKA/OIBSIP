const projects = [
  {
    title: "Parkinson’s Disease prediction in AI",
    url: "https://github.com/PRAYUKTHIKA/AIML-PROJECT"
  },
  {
    title: "Stylestore",
    url: "https://drive.google.com/file/d/1j8TsW5sIT46YagvWrSAF1AWuZXBUk08E/view"
  },
  {
    title: "Snake Game",
    url: "https://drive.google.com/file/d/1cPQ3qTkE6SyReqbEcw5FUr2xRMEeW_f7/view"
  }
];

const container = document.getElementById("project-container");

projects.forEach(project => {
  const link = document.createElement("a");
  link.href = project.url;
  link.target = "_blank";
  link.textContent = project.title;
  container.appendChild(link);
});
